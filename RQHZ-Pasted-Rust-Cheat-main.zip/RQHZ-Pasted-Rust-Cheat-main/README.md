# RQHZ-Pasted-Rust-Cheat
This Kid Clams To Not Paste As He Keeps On Getting Called Out For Pasting He Got Clowned So Hard He Deleted His Discord Account, I Got This Source Form A Kid That Paid For This Source Not Updated Just Take One Look At It And Make Fun Of This Skid
